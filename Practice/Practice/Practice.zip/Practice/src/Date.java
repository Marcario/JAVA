
import java.time.LocalDate;//importing the LocalDate class
import java.time.LocalTime;


public class Date {
    public static void main(String[] args){
//        LocalDate today =LocalDate.now();
//        LocalDate today = new LocalDate();
//        today.now();
        LocalTime today = LocalTime.now();
        System.out.println(today);
    }
}
